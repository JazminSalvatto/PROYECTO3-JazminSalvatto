/*Declaramos la funcion calcular total*/
export function calcularTotal(cantidad, plazo){
    const cantidadInt = parseInt(cantidad);
    const plazoInt = parseInt(plazo);
/*Mediante un if muestro la cantidad solicitada del prestamo y con respecto a eso se le asigna el interes ejemplo 0.250=25%*/
    let totalCantidad;
    if (cantidadInt <= 1000) {
        totalCantidad = cantidadInt * 0.10;
    } else if (cantidadInt > 1000 && cantidadInt <= 5000) {
        totalCantidad = cantidadInt * 0.150;
    }else if (cantidadInt > 5000 && cantidadInt <= 10000) {
        totalCantidad = cantidadInt * 0.20;
    }else {
        totalCantidad = cantidadInt * 0.25;
    }
/*use un swich para saber a que plazo sera el prestamo y con respecto a eso obtenemos el interes*/
    let totalPlazo;
    switch (plazoInt) {
        case 3:
            totalPlazo = cantidadInt * 0.10;
            break;
        case 6:
            totalPlazo = cantidadInt *0.15 ;
            break;
        case 12:
            totalPlazo = cantidadInt * 0.20;
            break;
        case 24:
            totalPlazo = cantidadInt * 0.25;
            break;
        default:
            break;
    }
    return totalCantidad + totalPlazo + cantidadInt;
    //console.log(totalPlazo);
}