import React from 'react';

const Mensaje = () => {
    return ( 
        <p>Ingrese una cantidad y un plazo...</p>
     );
}
 
export default Mensaje;